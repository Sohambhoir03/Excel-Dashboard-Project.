# Excel Retail Sales Performance Dashboard

## Overview
A portfolio-ready Excel dashboard project using a **synthetic retail sales dataset**. It demonstrates spreadsheet analysis, KPI reporting, formulas, and charts.

## Dashboard highlights
- Total revenue
- Total orders
- Unique customers
- Average order value
- Monthly revenue trend
- Revenue by country
- Revenue by product category

## Tools used
- Microsoft Excel
- Excel formulas: `SUM`, `SUMIF`, `SUMIFS`, `COUNTA`, `IFERROR`
- Charts and dashboard formatting

## Files
- `Retail_Sales_Performance_Dashboard.xlsx` — workbook with Dashboard, Sales Data, and Read Me sheets.

## How to use
1. Download and open the workbook in Microsoft Excel.
2. If prompted, allow formulas to recalculate.
3. Start from the **Dashboard** sheet.
4. Explore the **Sales Data** sheet to review the 1,200 sample transactions.

## Dataset note
All transaction records are synthetic and created for demonstration. They do not represent a real company or real customers.

## GitHub upload
Create a repository named `Excel-Retail-Sales-Dashboard`, upload the `.xlsx` file and this `README.md`, and add a screenshot of the Dashboard sheet if you want a stronger portfolio presentation.

## Future improvements
- Add PivotTables and slicers
- Add a top-10 countries analysis
- Add month-over-month growth
- Write 3–5 business insights based on the dashboard
